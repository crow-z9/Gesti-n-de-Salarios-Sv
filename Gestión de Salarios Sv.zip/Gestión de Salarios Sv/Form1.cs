﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace GestiondeSueldosSV
{
    public partial class Form1 : Form
    {
        string cadenaConexion = "Server=CNOVA\\SQLEXPRESS; Database=BD Salarios; Trusted_Connection=True;";

        public Form1()
        {
            InitializeComponent();
            CargarTabla();
        }

        private void CargarTabla()
        {
            try
            {
                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    string query = @"SELECT 
                                        e.IdEmpleado,
                                        e.Nombre, 
                                        e.Apellido, 
                                        e.Cargo, 
                                        s.SalarioBase, 
                                        s.Bono, 
                                        s.Deducciones, 
                                        s.SalarioBase - s.Deducciones AS SalarioNeto
                                     FROM Empleado e
                                     INNER JOIN Salario s ON e.IdEmpleado = s.IdEmpleado";

                    SqlDataAdapter adaptador = new SqlDataAdapter(query, conexion);
                    DataTable dt = new DataTable();
                    adaptador.Fill(dt);
                    dgvPlanilla.DataSource = dt;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al cargar la tabla: " + ex.Message);
            }
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtNombre.Text) || string.IsNullOrWhiteSpace(txtApellido.Text) || string.IsNullOrWhiteSpace(txtCargo.Text))
            {
                MessageBox.Show("Por favor llena todos los campos.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (!decimal.TryParse(txtSalarioBase.Text, out decimal salarioBase) || salarioBase <= 0)
            {
                MessageBox.Show("Ingresa un salario base válido.", "Aviso", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtSalarioBase.Focus();
                return;
            }

            try
            {
                decimal deducciones = Math.Round(salarioBase * 0.1025m, 2);
                decimal bono = 25.00m;

                using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                {
                    conexion.Open();

                    string queryEmp = "INSERT INTO Empleado (Nombre, Apellido, Cargo, IdDepartamento, FechaIngreso) VALUES (@nombre, @apellido, @cargo, 1, GETDATE()); SELECT SCOPE_IDENTITY();";
                    SqlCommand cmdEmp = new SqlCommand(queryEmp, conexion);
                    cmdEmp.Parameters.AddWithValue("@nombre", txtNombre.Text.Trim());
                    cmdEmp.Parameters.AddWithValue("@apellido", txtApellido.Text.Trim());
                    cmdEmp.Parameters.AddWithValue("@cargo", txtCargo.Text.Trim());

                    int idEmpleadoNuevo = Convert.ToInt32(cmdEmp.ExecuteScalar());

                    string querySal = @"INSERT INTO Salario (IdEmpleado, SalarioBase, Bono, Deducciones, MesCorrespondiente, MetodoPago, FechaPago) 
                                     VALUES (@idEmp, @base, @bono, @deducciones, 'Noviembre 2026', 'Transferencia', GETDATE())";
                    SqlCommand cmdSal = new SqlCommand(querySal, conexion);
                    cmdSal.Parameters.AddWithValue("@idEmp", idEmpleadoNuevo);
                    cmdSal.Parameters.AddWithValue("@base", salarioBase);
                    cmdSal.Parameters.AddWithValue("@bono", bono);
                    cmdSal.Parameters.AddWithValue("@deducciones", deducciones);

                    cmdSal.ExecuteNonQuery();
                }

                MessageBox.Show("¡Guardado y calculado con éxito!", "Éxito", MessageBoxButtons.OK, MessageBoxIcon.Information);
                CargarTabla();
                btnLimpiar_Click(sender, e);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error al guardar: " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnLimpiar_Click(object sender, EventArgs e)
        {
            txtNombre.Clear();
            txtApellido.Clear();
            txtCargo.Clear();
            txtSalarioBase.Clear();
            txtNombre.Focus();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (dgvPlanilla.SelectedRows.Count > 0)
            {
                int idEmpleado = Convert.ToInt32(dgvPlanilla.SelectedRows[0].Cells["IdEmpleado"].Value);

                if (MessageBox.Show("¿Deseas eliminar este registro?", "Confirmar", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
                {
                    try
                    {
                        using (SqlConnection conexion = new SqlConnection(cadenaConexion))
                        {
                            conexion.Open();

                            SqlCommand cmdSal = new SqlCommand("DELETE FROM Salario WHERE IdEmpleado = @id", conexion);
                            cmdSal.Parameters.AddWithValue("@id", idEmpleado);
                            cmdSal.ExecuteNonQuery();

                            SqlCommand cmdEmp = new SqlCommand("DELETE FROM Empleado WHERE IdEmpleado = @id", conexion);
                            cmdEmp.Parameters.AddWithValue("@id", idEmpleado);
                            cmdEmp.ExecuteNonQuery();

                            MessageBox.Show("¡Eliminado con éxito!");
                            CargarTabla();
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error al eliminar: " + ex.Message);
                    }
                }
            }
            else
            {
                MessageBox.Show("Selecciona una fila haciendo clic en la flecha de la izquierda de la tabla.");
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void dgvPlanilla_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}